const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

canvas.width = 800;
canvas.height = 600;

const paddleWidth = 10;
const paddleHeight = 100;
const ballRadius = 10;
const playerSpeed = 5;
const botSpeed = 5;
const ballMultiplier = 1.05;
const maxBallSpeed = 800;

let playerY = (canvas.height - paddleHeight) / 2;
let botY = (canvas.height - paddleHeight) / 2;
let playerX = 10; // Paddle'ları sahada daha ortada konumlandırmak için X koordinatları
let botX = canvas.width - 10 - paddleWidth;
let ballX = canvas.width / 2;
let ballY = canvas.height / 2;
let ballSpeedX = 500;
let ballSpeedY = 500;
let ballMoving = true;

let qtable_for_goal = {};

let playerScore = 0;
let botScore = 0;

// Gölge topun konumu ve hızı
let shadowBallX = ballX;
let shadowBallY = ballY;
let shadowBallSpeedX = ballSpeedX;
let shadowBallSpeedY = ballSpeedY;

function drawRect(x, y, width, height, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, width, height);
}

function drawCircle(x, y, radius, color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
}

function drawNet() {
    for (let i = 0; i < canvas.height; i += 20) {
        drawRect(canvas.width / 2 - 1, i, 2, 10, '#fff');
    }
}

function drawScore() {
    ctx.fillStyle = '#fff';
    ctx.font = '32px Arial';
    ctx.fillText(playerScore, canvas.width / 4, 50);
    ctx.fillText(botScore, 3 * canvas.width / 4, 50);
}

function movePlayer() {
    if (keys['w'] && playerY > 0) {
        playerY -= playerSpeed;
    }
    if (keys['s'] && playerY < canvas.height - paddleHeight) {
        playerY += playerSpeed;
    }
}

function moveBot() {
    if (ballSpeedX > 0) {
        // Gölge topu hareket ettir
        simulateShadowBall();

        // Gölge topun gelecekteki konumuna git
        let targetY = shadowBallY - paddleHeight / 2;
        if (botY < targetY) {
            botY += botSpeed;
            if (botY > targetY) botY = targetY;  // Hedefi geçmemek için
        } else if (botY > targetY) {
            botY -= botSpeed;
            if (botY < targetY) botY = targetY;  // Hedefi geçmemek için
        }

        // Bot paddle sahadan çıkmasını önlemek
        if (botY < 0) {
            botY = 0;
        }
        if (botY > canvas.height - paddleHeight) {
            botY = canvas.height - paddleHeight;
        }
    } else {
        // Top geri dönüyorsa paddle'ı merkeze geri döndür
        let centerY = (canvas.height - paddleHeight) / 2;
        if (botY < centerY) {
            botY += botSpeed;
            if (botY > centerY) botY = centerY;  // Hedefi geçmemek için
        } else if (botY > centerY) {
            botY -= botSpeed;
            if (botY < centerY) botY = centerY;  // Hedefi geçmemek için
        }
    }
}

function simulateShadowBall() {
    // Gölge topun hareketini simüle et
    shadowBallX = ballX;
    shadowBallY = ballY;
    shadowBallSpeedX = ballSpeedX;
    shadowBallSpeedY = ballSpeedY;

    while (shadowBallX + shadowBallSpeedX > paddleWidth && shadowBallX + shadowBallSpeedX < canvas.width - paddleWidth) {
        shadowBallX += shadowBallSpeedX;
        shadowBallY += shadowBallSpeedY;

        if (shadowBallY - ballRadius < 0 || shadowBallY + ballRadius > canvas.height) {
            shadowBallSpeedY = -shadowBallSpeedY;
        }
    }
}

function moveBall() {
    if (!ballMoving) return;

    ballX += (ballSpeedX / 60);
    ballY += (ballSpeedY / 60);

    if (ballY - ballRadius < 0 || ballY + ballRadius > canvas.height) {
        ballSpeedY = -ballSpeedY; // Topun saha sınırlarına çarpma kontrolüe
    }

    // Paddle'larla çarpışma kontrolü
    if (ballX - ballRadius < playerX + paddleWidth * 2 && ballY > playerY && ballY < playerY + paddleHeight) {
        ballSpeedX = -ballSpeedX * ballMultiplier;
        if (Math.abs(ballSpeedX) > maxBallSpeed) {
            ballSpeedX = ballSpeedX > 0 ? maxBallSpeed : -maxBallSpeed;
        }
        ballSpeedY = (ballY - (playerY + paddleHeight / 2)) / paddleHeight * 500;
    }

    if (ballX + ballRadius > botX && ballY > botY && ballY < botY + paddleHeight) {
        ballSpeedX = -ballSpeedX * ballMultiplier;
        if (Math.abs(ballSpeedX) > maxBallSpeed) {
            ballSpeedX = ballSpeedX > 0 ? maxBallSpeed : -maxBallSpeed;
        }
        ballSpeedY = (ballY - (botY + paddleHeight / 2)) / paddleHeight * 500;

        // Bot'un gol atma durumunda Q tablosunu güncelle
        let state = {
            playerY: Math.floor(playerY / 10) * 10,
            ballY: Math.floor(ballY / 10) * 10
        };

        if (qtable_for_goal[state.playerY + '-' + state.ballY]) {
            let qState = qtable_for_goal[state.playerY + '-' + state.ballY];
            ballSpeedY = qState.ballSpeedY;
            ballSpeedX = qState.ballSpeedX;
        }
        else {
            const randomOffset = (Math.random() - 0.5) * 100;
            let targetY;
            if (playerY > canvas.height * 0.66){
                targetY = canvas.height - playerY + randomOffset
            } 
            else if (playerY < canvas.height * 0.33){
                // get a number between -50 and 50
                targetY = canvas.height - playerY + randomOffset
            }
            else{
                if (Math.random() > 0.5){
                    targetY = canvas.height * 0.66 + randomOffset
                }
                else{
                    targetY = canvas.height * 0.33 + randomOffset
                }
            }
            ballSpeedY = (targetY - ballY) / canvas.height * 500;
        }
    }

    // Gol kontrolü (oyuncu golü)
    if (ballX - ballRadius < 0) {
        botScore++;
        ballMoving = false;
        setTimeout(() => {
            resetBall();
            checkWin();
        }, 1000); // 1 saniye duraklama
    }

    // Gol kontrolü (bot golü)
    if (ballX + ballRadius > canvas.width) {
        let state = {
            playerY: Math.floor(playerY / 10) * 10,
            ballY: Math.floor(ballY / 10) * 10
        };
        qtable_for_goal[state.playerY + '-' + state.ballY] = {
            ballSpeedY: ballSpeedY,
            ballSpeedX: ballSpeedX
        };
        playerScore++;
        ballMoving = false;
        setTimeout(() => {
            resetBall();
            checkWin();
        }, 1000); // 1 saniye duraklama
    }
}

function randomAngle() {
    return Math.random() * 8 - 4;  // Random angle between -4 and 4
}

function resetBall() {
    ballX = canvas.width / 2;
    ballY = canvas.height / 2;
    ballSpeedX = 500;
    ballSpeedY = randomAngle();

    // Top oyuncu tarafından vurulduğunda botun pozisyonuna göre yeni açıyı hesapla
    if (ballSpeedX < 0) {
        let botCenterY = botY + paddleHeight / 2;
        ballSpeedY = (botCenterY - ballY) / canvas.height * 500;
    }

    ballMoving = true;
}

function checkWin() {
    if (playerScore === 5 || botScore === 5) {
        let winner = playerScore === 5 ? 'Player' : 'Bot';
        alert(winner + ' wins!');
        playerScore = 0;
        botScore = 0;
        resetBall();
    }
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawNet();
    drawRect(playerX, playerY, paddleWidth, paddleHeight, '#fff');
    drawRect(botX, botY, paddleWidth, paddleHeight, '#fff');
    drawCircle(ballX, ballY, ballRadius, '#fff');
    drawScore();
}

function gameLoop() {
    movePlayer();
    moveBot();
    moveBall();
    draw();
    setTimeout(gameLoop, 1000 / 60);
}

const keys = {};
window.addEventListener('keydown', (e) => {
    keys[e.key] = true;
});

window.addEventListener('keyup', (e) => {
    keys[e.key] = false;
});

gameLoop();
