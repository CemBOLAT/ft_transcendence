const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

canvas.width = 800;
canvas.height = 600;

const paddleWidth = 10;
const paddleHeight = 100;
const ballRadius = 10;
const playerSpeed = 5;
const botSpeed = 5;
const ballMultiplier = 1.1;

let playerY = (canvas.height - paddleHeight) / 2;
let botY = (canvas.height - paddleHeight) / 2;
let playerX = 10; // Paddle'ları sahada daha ortada konumlandırmak için X koordinatları
let botX = canvas.width - 10 - paddleWidth;
let ballX = canvas.width / 2;
let ballY = canvas.height / 2;
let ballSpeedX = 4;
let ballSpeedY = 4;
let ballMoving = true;

let playerScore = 0;
let botScore = 0;

// Gölge topun konumu ve hızı
let shadowBallX = ballX;
let shadowBallY = ballY;
let shadowBallSpeedX = ballSpeedX;
let shadowBallSpeedY = ballSpeedY;

function drawRect(x, y, width, height, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, width, height);
}

function drawCircle(x, y, radius, color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
}

function drawNet() {
    for (let i = 0; i < canvas.height; i += 20) {
        drawRect(canvas.width / 2 - 1, i, 2, 10, '#fff');
    }
}

function drawScore() {
    ctx.fillStyle = '#fff';
    ctx.font = '32px Arial';
    ctx.fillText(playerScore, canvas.width / 4, 50);
    ctx.fillText(botScore, 3 * canvas.width / 4, 50);
}

function movePlayer() {
    if (keys['w'] && playerY > 0) {
        playerY -= playerSpeed;
    }
    if (keys['s'] && playerY < canvas.height - paddleHeight) {
        playerY += playerSpeed;
    }
}

function moveBot() {
    if (ballSpeedX > 0) {
        // Gölge topu hareket ettir
        simulateShadowBall();

        // Gölge topun gelecekteki konumuna git
        let targetY = shadowBallY - paddleHeight / 2;
        if (botY < targetY) {
            botY += botSpeed;
            if (botY > targetY) botY = targetY;  // Hedefi geçmemek için
        } else if (botY > targetY) {
            botY -= botSpeed;
            if (botY < targetY) botY = targetY;  // Hedefi geçmemek için
        }

        // Bot paddle sahadan çıkmasını önlemek
        if (botY < 0) {
            botY = 0;
        }
        if (botY > canvas.height - paddleHeight) {
            botY = canvas.height - paddleHeight;
        }
    } else {
        // Top geri dönüyorsa paddle'ı merkeze geri döndür
        let centerY = (canvas.height - paddleHeight) / 2;
        if (botY < centerY) {
            botY += botSpeed;
            if (botY > centerY) botY = centerY;  // Hedefi geçmemek için
        } else if (botY > centerY) {
            botY -= botSpeed;
            if (botY < centerY) botY = centerY;  // Hedefi geçmemek için
        }
    }
}

function simulateShadowBall() {
    // Gölge topun hareketini simüle et
    shadowBallX = ballX;
    shadowBallY = ballY;
    shadowBallSpeedX = ballSpeedX;
    shadowBallSpeedY = ballSpeedY;

    while (shadowBallX + shadowBallSpeedX > paddleWidth && shadowBallX + shadowBallSpeedX < canvas.width - paddleWidth) {
        shadowBallX += shadowBallSpeedX;
        shadowBallY += shadowBallSpeedY;

        if (shadowBallY - ballRadius < 0 || shadowBallY + ballRadius > canvas.height) {
            shadowBallSpeedY = -shadowBallSpeedY;
        }
    }
}

function moveBall() {
    if (!ballMoving) return;

    ballX += ballSpeedX;
    ballY += ballSpeedY;

    if (ballY - ballRadius < 0 || ballY + ballRadius > canvas.height) {
        ballSpeedY = -ballSpeedY;
    }

    // Çarpışma kontrolü (oyuncu paddle)
    if (ballX - ballRadius < playerX + paddleWidth && ballX - ballRadius > playerX && ballY > playerY && ballY < playerY + paddleHeight) {
        ballSpeedX = -ballSpeedX;
        ballSpeedY = randomAngle();
        ballSpeedX *= ballMultiplier;
        ballSpeedY *= ballMultiplier;
    }

    // Çarpışma kontrolü (bot paddle)
    if (ballX + ballRadius > botX && ballX + ballRadius < botX + paddleWidth && ballY > botY && ballY < botY + paddleHeight) {
        ballSpeedX = -ballSpeedX;
        ballSpeedY = randomAngle();
        ballSpeedX *= ballMultiplier;
        ballSpeedY *= ballMultiplier;
    }

    // Gol kontrolü (oyuncu golü)
    if (ballX - ballRadius < 0) {
        botScore++;
        ballMoving = false;
        setTimeout(() => {
            resetBall();
            checkWin();
        }, 1000); // 1 saniye duraklama
    }

    // Gol kontrolü (bot golü)
    if (ballX + ballRadius > canvas.width) {
        playerScore++;
        ballMoving = false;
        setTimeout(() => {
            resetBall();
            checkWin();
        }, 1000); // 1 saniye duraklama
    }
}

function randomAngle() {
    return Math.random() * 8 - 4;  // Random angle between -4 and 4
}

function resetBall() {
    ballX = canvas.width / 2;
    ballY = canvas.height / 2;
    ballSpeedX = -ballSpeedX / Math.abs(ballSpeedX) * 4; // Reset speed to initial value
    ballSpeedY = randomAngle();
    ballMoving = true;
}

function checkWin() {
    if (playerScore === 5 || botScore === 5) {
        let winner = playerScore === 5 ? 'Player' : 'Bot';
        alert(winner + ' wins!');
        playerScore = 0;
        botScore = 0;
        resetBall();
    }
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawNet();
    drawRect(playerX, playerY, paddleWidth, paddleHeight, '#fff');
    drawRect(botX, botY, paddleWidth, paddleHeight, '#fff');
    drawCircle(ballX, ballY, ballRadius, '#fff');
    drawScore();
}

function gameLoop() {
    movePlayer();
    moveBot();
    moveBall();
    draw();
    requestAnimationFrame(gameLoop);
}

const keys = {};
window.addEventListener('keydown', (e) => {
    keys[e.key] = true;
});

window.addEventListener('keyup', (e) => {
    keys[e.key] = false;
});

gameLoop();
